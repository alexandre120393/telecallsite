function is_cpf(cpf) {
    cpf = cpf.replace(/\D/g, '');

    if (cpf.length !== 11 || /^(\d)\1{10}$/.test(cpf)) {
        return false;
    }

    var sum = 0;
    var checkDigit = parseInt(cpf.substring(9, 10));

    for (var i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
    }

    var result = (sum * 10) % 11;
    if (result === 10 || result === 11) {
        result = 0;
    }

    if (result !== checkDigit) {
        return false;
    }

    sum = 0;
    checkDigit = parseInt(cpf.substring(10, 11));

    for (var i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
    }

    result = (sum * 10) % 11;
    if (result === 10 || result === 11) {
        result = 0;
    }

    if (result !== checkDigit) {
        return false;
    }

    return true;
}

function fMasc(objeto, mascara) {
    obj = objeto
    masc = mascara
    setTimeout("fMascEx()", 1)
}

function fMascEx() {
    obj.value = masc(obj.value)
}

function mCPF(cpf) {
    cpf = cpf.replace(/\D/g, "")
    cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2")
    cpf = cpf.replace(/(\d{3})(\d)/, "$1.$2")
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, "$1-$2")
    return cpf
}

cpfCheck = function (el) {
    document.getElementById('cpfResponse').innerHTML = is_cpf(el.value) ? '<br><span style="color:green">Valid CPF </span>' : '<br><span style="color:red">Enter a Valid CPF</span>';
    if (el.value == '') document.getElementById('cpfResponse').innerHTML = '';
}

function validatePhoneNumber(phoneNumberInput) {
    const phoneNumber = phoneNumberInput.value;
    const cleanedNumber = phoneNumber.replace(/\D/g, '');
    const validationMessage = document.getElementById('phoneValidationMessage');

    if (/^55\d{11}$/.test(cleanedNumber) && /^(\(0?[1-9][1-9]\)|[1-9][1-9])/.test(cleanedNumber)) {
        validationMessage.textContent = 'Valid Number.';
        validationMessage.style.color = 'green';
        phoneNumberInput.classList.remove('invalid');
        return true;
    } else {
        validationMessage.textContent = 'Enter a Valid Number.';
        validationMessage.style.color = 'red';
        phoneNumberInput.classList.add('invalid');
        return false;
    }
}

$("#cep").blur(function () {

    var cep = $(this).val().replace(/\D/g, '');

    if (cep != "") {

        var validacep = /^[0-9]{8}$/;

        if (validacep.test(cep)) {

            $("#rua2").val("...");
            $("#bairro").val("...");
            $("#cidade").val("...");
            $("#municipio").val("...");
            $("#uf").val("...");

            $.getJSON("https://viacep.com.br/ws/" + cep + "/json/?callback=?", function (dados) {

                if (!("erro" in dados)) {
                    $("#rua2").val(dados.logradouro);
                    $("#bairro").val(dados.bairro);
                    $("#cidade").val(dados.localidade);
                    $("#municipio").val(dados.municipio);
                    $("#uf").val(dados.uf);
                }
                else {
                    limpa_formulário_cep();
                    alert("Zip Code not found");
                }
            });
        }
        else {
            limpa_formulário_cep();
            alert("Invalid zip code format.");
        }
    }
    else {
        limpa_formulário_cep();
    }
});

function checkAge() {
    var inputDate = document.getElementById("dtnasc").value;
    var currentDate = new Date();
    var selectedDate = new Date(inputDate);
    var minAgeDate = new Date();
    minAgeDate.setFullYear(currentDate.getFullYear() - 18);

    if (selectedDate > minAgeDate) {
        showToast("You must be over 18 years old.");
        return false;
    }

    return true;
}

function showToast(message) {
    var toast = document.createElement("div");
    toast.className = "toast align-items-center text-white bg-primary border-0";
    toast.setAttribute("role", "alert");
    toast.setAttribute("aria-live", "assertive");
    toast.setAttribute("aria-atomic", "true");

    var toastBody = document.createElement("div");
    toastBody.className = "d-flex";
    toast.appendChild(toastBody);

    var toastIcon = document.createElement("i");
    toastIcon.className = "bi bi-check-circle-fill me-2";
    toastBody.appendChild(toastIcon);

    var toastMessage = document.createElement("div");
    toastMessage.className = "toast-body";
    toastMessage.innerText = message;
    toastBody.appendChild(toastMessage);

    var toastContainer = document.getElementById("toastContainer");
    toastContainer.appendChild(toast);

    var bsToast = new bootstrap.Toast(toast);
    bsToast.show();
}

function validar() {
    var nome = document.getElementById("nome").value;
    var nomeRegex = /^[A-Za-z ]{15,60}$/;
    var email = document.getElementById("email").value;
    var dtnasc = document.getElementById("dtnasc").value;
    var sexo = document.getElementById("sexo").value;
    var nomemae = document.getElementById("nomemae").value;
    var nomemaeRegex = /^[A-Za-z ]{15,60}$/;
    var cpf = document.getElementById("cpf").value;
    var cel = document.getElementById("cel").value;
    var telfixo = document.getElementById("telfixo").value;
    var cep = document.getElementById("cep").value;
    var login = document.getElementById("login").value;
    var senha = document.getElementById("senha").value;
    var confsenha = document.getElementById("confsenha").value;


    if (nome.trim() === "") {
        showToast("Please enter Name.");
        return false;
    }
    if (!nomeRegex.test(nome)) {
        showToast("The Name must contain only alphabetic characters and be between 15 and 60 characters long.");
        return false;
    }

    if (email.trim() === "") {
        showToast("Please enter Email.");
        return false;
    }
    if (email.indexOf("@") === -1 || !/(.com|.org|.ong|.edu|.gov)$/i.test(email)) {
        showToast("The Email must contain a valid email address.");
        return false;
    }


    if (dtnasc.trim() === "") {
        showToast("Please enter Date of Birth.");
        return false;
    }

    if (sexo.trim() === "") {
        showToast("Please select a Gender option.");
        return false;
    }

    if (nomemae.trim() !== '') {
        if (!nomemaeRegex.test(nomemae)) {
            showToast("The Maternal Name must contain only alphabetic characters and be between 15 and 60 characters long.");
            return false;
        }
    }


    if (cpf.trim() === "") {
        showToast("Please enter CPF ");
        return false;
    }

    if (cel.trim() === "") {
        showToast("Please enter Cell phone.");
        return false;
    }
    var celRegex = /^\(\+55\)\d{2}-\d{9}$/;
    if (!celRegex.test(cel)) {
        showToast("Cell Phone must be in (+55)xx-xxxxxxxxx format.");
        return false;
    }

    if (telfixo.trim() !== '') {
        var telfixoRegex = /^\(\+55\)\d{2}-\d{9}$/;
        if (!telfixoRegex.test(telfixo)) {
            showToast("The Land Line must bem in (+55)xx-xxxxxxxxx format.");
            return false;
        }
    }

    if (cep.trim() === "") {
        showToast("Please enter Zip Code.");
        return false;
    }

    if (login.trim() === "6") {
        showToast("Please enter Login.");
        return false;
    }

    var loginRegex = /^[A-Za-z]{6}$/;
    if (!loginRegex.test(login)) {
        showToast("The Login must contain exactly 6 alphabetic characters..");
        return false;
    }

    if (senha.trim().length < 8) {
        showToast("Password must be at least 8 characters.");
        return false;
    }


    if (confsenha.trim() === "") {
        showToast("Please enter Confirm Password.");
        return false;
    }

    if (senha !== confsenha) {
        showToast("The passwords do not match.");
        return false;
    }

    if (!is_cpf(cpf)) {
        showToast("The CPF entered is not valid.");
        return false;
    }

    if (!validatePhoneNumber(document.getElementById("cel"))) {
        showToast("The Cell phone is not valid.");
        return false;
    }

    if (telfixo.trim() !== '') {
        if (!validatePhoneNumber(document.getElementById("telfixo"))) {
            showToast("The Land Line is not valid.");
            return false;
        }
    }

    if (!checkAge()) {
        return false;
    }



    localStorage.setItem("nome", $("#nome").val());
    localStorage.setItem("email", email);
    localStorage.setItem("dtnasc", dtnasc);
    localStorage.setItem("sexo", sexo);
    localStorage.setItem("nomemae", nomemae);
    localStorage.setItem("cpf", cpf);
    localStorage.setItem("cel", cel);
    localStorage.setItem("telfixo", telfixo);
    localStorage.setItem("cep", cep);
    localStorage.setItem("login", $("#login").val());
    localStorage.setItem("senhacadastro", $("#confsenha").val());


    return true;
}

$(document).ready(function () {
    $("form").submit(function (event) {
        event.preventDefault();
        validar();
    });
});

$("#rua2").attr("disabled", "disable");
$("#cidade").attr("disabled", "disable");
$("#bairro").attr("disabled", "disable");
$("#uf").attr("disabled", "disable");



